import { Hook } from '@oclif/config';
export declare const version: Hook.Init;
